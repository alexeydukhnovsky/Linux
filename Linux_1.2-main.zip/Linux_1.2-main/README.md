«Create Ubuntu 20.04 VM»
